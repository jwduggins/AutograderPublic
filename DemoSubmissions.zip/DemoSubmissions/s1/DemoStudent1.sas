options nosyntaxcheck;

/*two syntax errors with different MSGINFO in log*/
optionss formdelim = "~";

/*Operation on missing values, Uninitialized variable,
  Implicit Conversion, Lost Card*/
data Set1;
  input x y z $;
  OpOnMiss = x + y;
  Uninit = x + a;
  ImpConv = x + z;
  cards;
1 2 3
4 . 6
7 8
  ;
run;

/*syntax error as warning*/
porc means data = sashelp.cars;
run;

/*recoverable syntax error as a different warning 
  AND
  unrecoverable syntax error*/
proc prints data = sashelp.cars(obs = 5)
           sapphire;
run;

*Semantic error + 2 warnings;
data set3;
  set set2;
run;

*warning;
ods _all_ close;
proc print data = sashelp.cars;
run;

quit;
