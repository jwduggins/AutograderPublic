x "cd S:\Student2\Demo";
libname Demo ".";

ods pdf file = "Student2 Demo Report.pdf";
proc means data = sashelp.cars;
run;
ods pdf close;

quit;
